import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const WeatherApp());

class WeatherApp extends StatelessWidget {
  const WeatherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: WeatherHome(),
    );
  }
}

class WeatherHome extends StatefulWidget {
  @override
  State<WeatherHome> createState() => _WeatherHomeState();
}

class _WeatherHomeState extends State<WeatherHome> {
  final TextEditingController cityController = TextEditingController();
  String apiKey = "f9f9c307030e05373c5bfc8d4dd43d1d";

  Map<String, dynamic>? currentWeather;
  List<dynamic> forecast = [];
  List<String> history = [];
  bool loading = false;
  String? error;

  @override
  void initState() {
    super.initState();
    loadLastCities();
  }

  Future<void> loadLastCities() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    history = prefs.getStringList("history") ?? [];
    if (history.isNotEmpty) {
      cityController.text = history.last;
      fetchWeather(history.last);
    }
    setState(() {});
  }

  Future<void> saveCity(String city) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (!history.contains(city)) history.add(city);
    if (history.length > 5) history.removeAt(0); // Keep last 5 cities
    await prefs.setStringList("history", history);
    setState(() {});
  }

  Future<void> fetchWeather(String city) async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final currentUrl =
          "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric";
      final forecastUrl =
          "https://api.openweathermap.org/data/2.5/forecast?q=$city&appid=$apiKey&units=metric";

      final currentResponse = await http.get(Uri.parse(currentUrl));
      final forecastResponse = await http.get(Uri.parse(forecastUrl));

      if (currentResponse.statusCode != 200) {
        setState(() {
          error = "City not found!";
          loading = false;
        });
        return;
      }

      setState(() {
        currentWeather = json.decode(currentResponse.body);
        forecast = json
            .decode(forecastResponse.body)["list"]
            .take(56)
            .toList();
        loading = false;
      });

      saveCity(city);
    } catch (e) {
      setState(() {
        error = "No Internet Connection!";
        loading = false;
      });
    }
  }

  String getWeatherIcon(String desc) {
    desc = desc.toLowerCase();
    if (desc.contains("cloud")) return "assets/images/cloud.png";
    if (desc.contains("rain")) return "assets/images/rain.png";
    if (desc.contains("snow")) return "assets/images/snow.png";
    return "assets/images/sun.png";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF73AEF5), Color(0xFF398AE5)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                // Search Bar
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: cityController,
                        decoration: InputDecoration(
                          hintText: "Enter city name",
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.8),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () =>
                          fetchWeather(cityController.text.trim()),
                      child: const Icon(Icons.search),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.all(14),
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 10),

                // Search History
                if (history.isNotEmpty)
                  SizedBox(
                    height: 40,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: history.length,
                      itemBuilder: (context, i) => Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4.0),
                        child: ActionChip(
                          label: Text(history[i]),
                          onPressed: () => fetchWeather(history[i]),
                          backgroundColor: Colors.white.withOpacity(0.8),
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 20),

                if (loading)
                  const CircularProgressIndicator(color: Colors.white),
                if (error != null)
                  Text(error!,
                      style: const TextStyle(
                          color: Colors.red,
                          fontSize: 18,
                          fontWeight: FontWeight.bold)),
                if (!loading && error == null && currentWeather != null)
                  Expanded(
                    child: ListView(
                      children: [
                        // CURRENT WEATHER
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.white.withOpacity(0.9), Colors.white.withOpacity(0.7)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Column(
                            children: [
                              Text(
                                "${currentWeather!["name"]}",
                                style: const TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 10),
                              Image.asset(
                                getWeatherIcon(
                                    currentWeather!["weather"][0]["description"]),
                                width: 80,
                              ),
                              const SizedBox(height: 10),
                              Text(
                                "${currentWeather!["main"]["temp"]}°C",
                                style: const TextStyle(
                                    fontSize: 40,
                                    fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                "${currentWeather!["weather"][0]["description"]}",
                                style: const TextStyle(
                                    fontSize: 20,
                                    fontStyle: FontStyle.italic),
                              ),
                              const SizedBox(height: 20),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Column(
                                    children: [
                                      Image.asset(
                                          "assets/images/humidity.png",
                                          width: 30),
                                      const SizedBox(height: 5),
                                      Text(
                                          "${currentWeather!["main"]["humidity"]}%"),
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      Image.asset(
                                          "assets/images/wind.png",
                                          width: 30),
                                      const SizedBox(height: 5),
                                      Text(
                                          "${currentWeather!["wind"]["speed"]} m/s"),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),

                        // 7-DAY FORECAST
                        Text("7-Day Forecast",
                            style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.white)),
                        const SizedBox(height: 10),

                        Container(
                          height: 160,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: 7,
                            itemBuilder: (context, i) {
                              int index = i * 8;
                              if (index >= forecast.length) index = forecast.length - 1;
                              final f = forecast[index];
                              final date = DateTime.parse(f["dt_txt"]);
                              return Container(
                                width: 130,
                                margin: const EdgeInsets.symmetric(horizontal: 8),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [Colors.white.withOpacity(0.8), Colors.white.withOpacity(0.6)],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text("${date.day}/${date.month}",
                                        style: const TextStyle(fontWeight: FontWeight.bold)),
                                    const SizedBox(height: 5),
                                    Image.asset(getWeatherIcon(
                                        f["weather"][0]["description"]),
                                        width: 40),
                                    const SizedBox(height: 5),
                                    Text(
                                      "${f["main"]["temp_min"]}°C - ${f["main"]["temp_max"]}°C",
                                      textAlign: TextAlign.center,
                                    ),
                                    Text(
                                      "${f["weather"][0]["description"]}",
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
